<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    /**
     * Página principal que muestra opciones de JOIN
     */
    public function index()
    {
        return view('products.index');
    }

    /**
     * Ejemplo de INNER JOIN - Solo productos con categoría
     */
    public function innerJoin()
    {
        // Usando Query Builder
        $productsQB = DB::table('products')
            ->join('categories', 'products.category_id', '=', 'categories.id')
            ->select('products.*', 'categories.name as category_name')
            ->get();

        // Usando Eloquent
        $productsEloquent = Product::join('categories', 'products.category_id', '=', 'categories.id')
            ->select('products.*', 'categories.name as category_name')
            ->get();

        // Usando relaciones de Eloquent (más recomendado)
        $productsRelation = Product::with('category')->whereHas('category')->get();

        return view('products.join', [
            'title' => 'INNER JOIN',
            'description' => 'El INNER JOIN muestra solo productos que tienen una categoría asignada.',
            'productsQB' => $productsQB,
            'productsEloquent' => $productsEloquent,
            'productsRelation' => $productsRelation
        ]);
    }

    /**
     * Ejemplo de LEFT JOIN - Todos los productos, tengan o no categoría
     */
    public function leftJoin()
    {
        // Usando solo Eloquent
        $productsEloquent = Product::leftJoin('categories', 'products.category_id', '=', 'categories.id')
            ->select('products.*', 'categories.name as category_name')
            ->get();

        return view('products.join', [
            'title' => 'LEFT JOIN',
            'description' => 'El LEFT JOIN muestra todos los productos, incluso aquellos sin categoría.',
            'productsEloquent' => $productsEloquent
        ]);
    }

    /**
     * Ejemplo de RIGHT JOIN - Todas las categorías, tengan o no productos
     */
    public function rightJoin()
    {
        // Usando solo Eloquent
        $categoriesEloquent = Category::rightJoin('products', 'categories.id', '=', 'products.category_id')
            ->select('categories.*', 'products.name as product_name')
            ->get();

        return view('products.right_join', [
            'title' => 'RIGHT JOIN',
            'description' => 'El RIGHT JOIN muestra todas las categorías y los productos asociados a ellas.',
            'categoriesEloquent' => $categoriesEloquent
        ]);
    }

    /**
     * Ejemplo de CROSS JOIN - Todas las combinaciones posibles
     */
    public function crossJoin()
    {
        // Usando Eloquent con crossJoin
        $results = DB::table('products')
            ->crossJoin('categories')
            ->select('products.name as product_name', 'categories.name as category_name')
            ->get();

        return view('products.cross_join', [
            'title' => 'CROSS JOIN',
            'description' => 'El CROSS JOIN muestra todas las combinaciones posibles entre productos y categorías.',
            'results' => $results
        ]);
    }
}