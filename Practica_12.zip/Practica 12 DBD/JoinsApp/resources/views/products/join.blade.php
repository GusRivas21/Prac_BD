<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title }} - JOIN en Laravel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('home') }}">Inicio</a></li>
                <li class="breadcrumb-item active" aria-current="page">{{ $title }}</li>
            </ol>
        </nav>
        
        <h1 class="mb-4">{{ $title }}</h1>
        <p class="lead">{{ $description }}</p>
        
        <div class="row mt-5">
            @if($title == 'INNER JOIN')
            <div class="col-md-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        Usando Query Builder
                    </div>
                    <div class="card-body">
                        <pre class="bg-light p-3">
DB::table('products')
    ->join('categories', 'products.category_id', '=', 'categories.id')
    ->select('products.*', 'categories.name as category_name')
    ->get();
                        </pre>
                        
                        <h5 class="mt-4">Resultados:</h5>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Precio</th>
                                    <th>Categoría</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($productsQB as $product)
                                <tr>
                                    <td>{{ $product->id }}</td>
                                    <td>{{ $product->name }}</td>
                                    <td>${{ $product->price }}</td>
                                    <td>{{ $product->category_name ?? 'Sin categoría' }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            @endif
            
            <div class="col-md-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        Usando Eloquent (Método de JOIN)
                    </div>
                    <div class="card-body">
                        <pre class="bg-light p-3">
{{ $title == 'INNER JOIN' ? 'Product::join' : 'Product::leftJoin' }}('categories', 'products.category_id', '=', 'categories.id')
    ->select('products.*', 'categories.name as category_name')
    ->get();
                        </pre>
                        
                        <h5 class="mt-4">Resultados:</h5>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Precio</th>
                                    <th>Categoría</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($productsEloquent as $product)
                                <tr>
                                    <td>{{ $product->id }}</td>
                                    <td>{{ $product->name }}</td>
                                    <td>${{ $product->price }}</td>
                                    <td>{{ $product->category_name ?? 'Sin categoría' }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            @if($title == 'INNER JOIN')
            <div class="col-md-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        Usando Relaciones de Eloquent (Recomendado)
                    </div>
                    <div class="card-body">
                        <pre class="bg-light p-3">
Product::with('category')->whereHas('category')->get();
                        </pre>
                        
                        <h5 class="mt-4">Resultados:</h5>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Precio</th>
                                    <th>Categoría</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($productsRelation as $product)
                                <tr>
                                    <td>{{ $product->id }}</td>
                                    <td>{{ $product->name }}</td>
                                    <td>${{ $product->price }}</td>
                                    <td>{{ $product->category->name ?? 'Sin categoría' }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            @endif
        </div>
        
        <a href="{{ route('home') }}" class="btn btn-secondary mb-5">Volver al inicio</a>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>