<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOIN en Laravel - Ejemplos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Ejemplos de JOIN en Laravel</h1>
        
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">¿Qué son los JOIN?</h5>
                <p class="card-text">
                    Los JOIN son operaciones que permiten combinar filas de dos o más tablas basándose en una columna relacionada entre ellas.
                    En Laravel, podemos utilizar JOIN de diferentes maneras, tanto con Query Builder como con Eloquent ORM.
                </p>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        INNER JOIN
                    </div>
                    <div class="card-body">
                        <p class="card-text">Muestra solo los registros que tienen coincidencias en ambas tablas.</p>
                        <a href="{{ route('inner.join') }}" class="btn btn-primary">Ver ejemplo</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        LEFT JOIN
                    </div>
                    <div class="card-body">
                        <p class="card-text">Muestra todos los registros de la tabla izquierda y las coincidencias de la tabla derecha.</p>
                        <a href="{{ route('left.join') }}" class="btn btn-success">Ver ejemplo</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        RIGHT JOIN
                    </div>
                    <div class="card-body">
                        <p class="card-text">Muestra todos los registros de la tabla derecha y las coincidencias de la tabla izquierda.</p>
                        <a href="{{ route('right.join') }}" class="btn btn-info">Ver ejemplo</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        CROSS JOIN
                    </div>
                    <div class="card-body">
                        <p class="card-text">Devuelve el producto cartesiano de las tablas involucradas (todas las combinaciones posibles).</p>
                        <a href="{{ route('cross.join') }}" class="btn btn-warning">Ver ejemplo</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="mt-4">
            <h3>Estructura de tablas</h3>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            Tabla: categories
                        </div>
                        <div class="card-body">
                            <pre>
                    id  | name        | description
                    ----|-------------|------------------
                    1   | Electrónica | Productos electrónicos
                    2   | Ropa        | Ropa y accesorios
                    3   | Alimentos   | Comida y bebidas
                            </pre>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            Tabla: products
                        </div>
                        <div class="card-body">
                            <pre>
                    id | name        | price   | category_id
                    ---|-------------|---------|------------
                    1  | Laptop      | 1200.00 | 1
                    2  | Smartphone  | 800.00  | 1
                    3  | Camiseta    | 20.00   | 2
                    4  | Pantalones  | 45.00   | 2
                    5  | Chocolate   | 5.00    | 3
                    6  | Prod. Esp.  | 150.00  | NULL
                            </pre>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>