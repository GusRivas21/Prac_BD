<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\Product;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Crear categorías
        $electronics = Category::create([
            'name' => 'Electrónica',
            'description' => 'Productos electrónicos y dispositivos'
        ]);

        $clothing = Category::create([
            'name' => 'Ropa',
            'description' => 'Ropa y accesorios'
        ]);

        $food = Category::create([
            'name' => 'Alimentos',
            'description' => 'Comida y bebidas'
        ]);

        // Crear productos con categorías
        Product::create([
            'name' => 'Laptop',
            'price' => 1200.00,
            'description' => 'Laptop de alta gama',
            'category_id' => $electronics->id
        ]);

        Product::create([
            'name' => 'Smartphone',
            'price' => 800.00,
            'description' => 'Teléfono inteligente',
            'category_id' => $electronics->id
        ]);

        Product::create([
            'name' => 'Camiseta',
            'price' => 20.00,
            'description' => 'Camiseta de algodón',
            'category_id' => $clothing->id
        ]);

        Product::create([
            'name' => 'Pantalones',
            'price' => 45.00,
            'description' => 'Pantalones vaqueros',
            'category_id' => $clothing->id
        ]);

        Product::create([
            'name' => 'Chocolate',
            'price' => 5.00,
            'description' => 'Barra de chocolate',
            'category_id' => $food->id
        ]);

        // Producto sin categoría
        Product::create([
            'name' => 'Producto Especial',
            'price' => 150.00,
            'description' => 'Producto sin categoría',
            'category_id' => null
        ]);
    }
}