<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', [ProductController::class, 'index'])->name('home');
Route::get('/inner-join', [ProductController::class, 'innerJoin'])->name('inner.join');
Route::get('/left-join', [ProductController::class, 'leftJoin'])->name('left.join');
Route::get('/right-join', [ProductController::class, 'rightJoin'])->name('right.join');
Route::get('/cross-join', [ProductController::class, 'crossJoin'])->name('cross.join');