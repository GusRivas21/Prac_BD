<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?> - JOIN en Laravel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($title); ?></li>
            </ol>
        </nav>
        
        <h1 class="mb-4"><?php echo e($title); ?></h1>
        <p class="lead"><?php echo e($description); ?></p>
        
        <div class="row mt-5">
            <div class="col-md-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        Usando Eloquent (Método de JOIN)
                    </div>
                    <div class="card-body">
                        <pre class="bg-light p-3">
Category::rightJoin('products', 'categories.id', '=', 'products.category_id')
    ->select('categories.*', 'products.name as product_name')
    ->get();
                        </pre>
                        
                        <h5 class="mt-4">Resultados:</h5>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID Categoría</th>
                                    <th>Nombre Categoría</th>
                                    <th>Producto</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categoriesEloquent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($category->id ?? 'NULL'); ?></td>
                                    <td><?php echo e($category->name ?? 'Sin categoría'); ?></td>
                                    <td><?php echo e($category->product_name); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary mb-5">Volver al inicio</a>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\Users\Williams\Herd\JoinsApp\resources\views/products/right_join.blade.php ENDPATH**/ ?>