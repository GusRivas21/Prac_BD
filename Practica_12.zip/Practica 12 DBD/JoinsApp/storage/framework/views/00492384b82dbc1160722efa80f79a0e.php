<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?> - JOIN en Laravel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($title); ?></li>
            </ol>
        </nav>
        
        <h1 class="mb-4"><?php echo e($title); ?></h1>
        <p class="lead"><?php echo e($description); ?></p>
        
        <div class="row mt-5">
            <?php if($title == 'INNER JOIN'): ?>
            <div class="col-md-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        Usando Query Builder
                    </div>
                    <div class="card-body">
                        <pre class="bg-light p-3">
DB::table('products')
    ->join('categories', 'products.category_id', '=', 'categories.id')
    ->select('products.*', 'categories.name as category_name')
    ->get();
                        </pre>
                        
                        <h5 class="mt-4">Resultados:</h5>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Precio</th>
                                    <th>Categoría</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $productsQB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($product->id); ?></td>
                                    <td><?php echo e($product->name); ?></td>
                                    <td>$<?php echo e($product->price); ?></td>
                                    <td><?php echo e($product->category_name ?? 'Sin categoría'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="col-md-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        Usando Eloquent (Método de JOIN)
                    </div>
                    <div class="card-body">
                        <pre class="bg-light p-3">
<?php echo e($title == 'INNER JOIN' ? 'Product::join' : 'Product::leftJoin'); ?>('categories', 'products.category_id', '=', 'categories.id')
    ->select('products.*', 'categories.name as category_name')
    ->get();
                        </pre>
                        
                        <h5 class="mt-4">Resultados:</h5>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Precio</th>
                                    <th>Categoría</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $productsEloquent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($product->id); ?></td>
                                    <td><?php echo e($product->name); ?></td>
                                    <td>$<?php echo e($product->price); ?></td>
                                    <td><?php echo e($product->category_name ?? 'Sin categoría'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <?php if($title == 'INNER JOIN'): ?>
            <div class="col-md-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        Usando Relaciones de Eloquent (Recomendado)
                    </div>
                    <div class="card-body">
                        <pre class="bg-light p-3">
Product::with('category')->whereHas('category')->get();
                        </pre>
                        
                        <h5 class="mt-4">Resultados:</h5>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Precio</th>
                                    <th>Categoría</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $productsRelation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($product->id); ?></td>
                                    <td><?php echo e($product->name); ?></td>
                                    <td>$<?php echo e($product->price); ?></td>
                                    <td><?php echo e($product->category->name ?? 'Sin categoría'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary mb-5">Volver al inicio</a>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\Users\Williams\Herd\JoinsApp\resources\views/products/join.blade.php ENDPATH**/ ?>