<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?> - JOIN en Laravel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($title); ?></li>
            </ol>
        </nav>
        
        <h1 class="mb-4"><?php echo e($title); ?></h1>
        <p class="lead"><?php echo e($description); ?></p>
        
        <div class="row mt-5">
            <div class="col-md-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        Usando Query Builder
                    </div>
                    <div class="card-body">
                        <pre class="bg-light p-3">
DB::table('products')
    ->crossJoin('categories')
    ->select('products.name as product_name', 'categories.name as category_name')
    ->get();
                        </pre>
                        
                        <h5 class="mt-4">Resultados (Producto Cartesiano):</h5>
                        <p>Un CROSS JOIN crea todas las combinaciones posibles entre las filas de la primera tabla y las filas de la segunda tabla, sin importar si tienen relación o no.</p>
                        
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Producto</th>
                                    <th>Categoría</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($result->product_name); ?></td>
                                    <td><?php echo e($result->category_name); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        
                        <div class="alert alert-info mt-4">
                            <h5>Explicación:</h5>
                            <p>
                                En este ejemplo, cada producto se combina con cada categoría, sin importar si el producto pertenece realmente a esa categoría.
                                Por ejemplo, la "Laptop" se muestra combinada con todas las categorías (Electrónica, Ropa, Alimentos), aunque realmente solo pertenece a "Electrónica".
                            </p>
                            <p>
                                El número total de filas en el resultado del CROSS JOIN será igual al número de filas en la primera tabla multiplicado por el número de filas en la segunda tabla.
                                En este caso, 6 productos × 3 categorías = 18 combinaciones.
                            </p>
                            <p>
                                <strong>Nota:</strong> Los CROSS JOIN rara vez se usan en aplicaciones reales, pero son útiles para entender el concepto de producto cartesiano en bases de datos.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary mb-5">Volver al inicio</a>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\Users\Williams\Herd\JoinsApp\resources\views/products/cross_join.blade.php ENDPATH**/ ?>