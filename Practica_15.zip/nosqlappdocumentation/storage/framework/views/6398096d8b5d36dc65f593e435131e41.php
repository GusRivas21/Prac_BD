<!DOCTYPE html>
<html>
<head>
    <title>CRUD Laravel con MongoDB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Laravel MongoDB CRUD</a>
        </div>
    </nav>
    
    <div class="container mt-5">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\Users\Williams\Herd\nosqlapprelaciones\resources\views/layouts/app.blade.php ENDPATH**/ ?>