

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h2>Lista de Productos</h2>
                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-success mb-3">Crear Nuevo Producto</a>
                       
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>
                       
                        <table class="table table-bordered">
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th>Precio</th>
                                <th>Stock</th>
                                <th width="280px">Acción</th>
                            </tr>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($producto->_id); ?></td>
                                <td><?php echo e($producto->nombre); ?></td>
                                <td><?php echo e($producto->descripcion); ?></td>
                                <td>$<?php echo e($producto->precio); ?></td>
                                <td><?php echo e($producto->stock); ?></td>
                                <td>
                                    <form action="<?php echo e(route('productos.destroy',$producto->_id)); ?>" method="POST">
                                        <a class="btn btn-info btn-sm" href="<?php echo e(route('productos.show',$producto->_id)); ?>">Ver</a>
                                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('productos.edit',$producto->_id)); ?>">Editar</a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Williams\Herd\nosqlapp\resources\views/productos/index.blade.php ENDPATH**/ ?>