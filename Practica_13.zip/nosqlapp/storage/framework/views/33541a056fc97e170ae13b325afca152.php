

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h2>Crear Nuevo Producto</h2>
                    </div>
                    <div class="card-body">
                        <a class="btn btn-primary" href="<?php echo e(route('productos.index')); ?>">Volver</a>
                        <br><br>
                       
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <strong>¡Error!</strong> Hay problemas con los datos ingresados.<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                       
                        <form action="<?php echo e(route('productos.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                         
                             <div class="form-group">
                                <label for="nombre">Nombre:</label>
                                <input type="text" name="nombre" class="form-control" placeholder="Nombre del producto">
                            </div>
                         
                            <div class="form-group">
                                <label for="descripcion">Descripción:</label>
                                <textarea class="form-control" name="descripcion" placeholder="Descripción del producto"></textarea>
                            </div>
                         
                            <div class="form-group">
                                <label for="precio">Precio:</label>
                                <input type="number" step="0.01" name="precio" class="form-control" placeholder="Precio">
                            </div>
                         
                            <div class="form-group">
                                <label for="stock">Stock:</label>
                                <input type="number" name="stock" class="form-control" placeholder="Cantidad en stock">
                            </div>
                        
                            <button type="submit" class="btn btn-success mt-3">Guardar</button>
                         
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Williams\Herd\nosqlapp\resources\views/productos/create.blade.php ENDPATH**/ ?>