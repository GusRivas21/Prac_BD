

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h2>Detalles del Producto</h2>
                    </div>
                    <div class="card-body">
                        <a class="btn btn-primary" href="<?php echo e(route('productos.index')); ?>">Volver</a>
                        <br><br>
                       
                        <div class="form-group">
                            <strong>ID:</strong>
                            <?php echo e($producto->_id); ?>

                        </div>
                        
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e($producto->nombre); ?>

                        </div>
                        
                        <div class="form-group">
                            <strong>Descripción:</strong>
                            <?php echo e($producto->descripcion); ?>

                        </div>
                        
                        <div class="form-group">
                            <strong>Precio:</strong>
                            $<?php echo e($producto->precio); ?>

                        </div>
                        
                        <div class="form-group">
                            <strong>Stock:</strong>
                            <?php echo e($producto->stock); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Williams\Herd\nosqlapp\resources\views/productos/show.blade.php ENDPATH**/ ?>