

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h2>Editar Producto</h2>
                    </div>
                    <div class="card-body">
                        <a class="btn btn-primary" href="<?php echo e(route('productos.index')); ?>">Volver</a>
                        <br><br>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <strong>¡Error!</strong> Hay problemas con los datos ingresados.<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('productos.update', $producto->_id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="form-group">
                                <label for="nombre">Nombre:</label>
                                <input type="text" name="nombre" value="<?php echo e($producto->nombre); ?>" class="form-control" placeholder="Nombre del producto">
                            </div>

                            <div class="form-group">
                                <label for="descripcion">Descripción:</label>
                                <textarea class="form-control" name="descripcion" placeholder="Descripción del producto"><?php echo e($producto->descripcion); ?></textarea>
                            </div>

                            <div class="form-group">
                                <label for="precio">Precio:</label>
                                <input type="number" step="0.01" name="precio" value="<?php echo e($producto->precio); ?>" class="form-control" placeholder="Precio">
                            </div>

                            <div class="form-group">
                                <label for="stock">Stock:</label>
                                <input type="number" name="stock" value="<?php echo e($producto->stock); ?>" class="form-control" placeholder="Cantidad en stock">
                            </div>

                            <div class="form-group">
                                <label for="categoria_id">Categoría:</label>
                                <select name="categoria_id" class="form-control" required>
                                    <option value="">Seleccione una categoría</option>
                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($categoria->_id); ?>"
                                            <?php echo e($producto->categoria_id == $categoria->_id ? 'selected' : ''); ?>>
                                            <?php echo e($categoria->nombre); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-success mt-3">Actualizar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Williams\Herd\nosqlapp\resources\views/productos/edit.blade.php ENDPATH**/ ?>